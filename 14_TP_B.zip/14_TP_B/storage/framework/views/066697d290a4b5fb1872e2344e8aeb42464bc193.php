<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Admin area</title>

    <!-- Scripts -->

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="<?php echo e(asset('public/css/template.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('public/css/admin.css')); ?>" rel="stylesheet">
</head>

<body>
    <div class="row">
        <nav class="small-4 col">
            <ul>
                <li><a href="<?php echo e(route('nav')); ?>">Main Nav</a></li>
                <li><a href="<?php echo e(route('symbols')); ?>">Design Symbols</a></li>
                <li><a href="<?php echo e(route('orders')); ?>">Pre-Orders</a></li>
                <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">Logout</a></li>
            </ul>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"><?php echo csrf_field(); ?></form>
        </nav>
    </div>


    <div class="row">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>

</html>
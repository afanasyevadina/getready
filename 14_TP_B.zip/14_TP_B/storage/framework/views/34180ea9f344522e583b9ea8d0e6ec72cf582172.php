<?php $__env->startSection('content'); ?>
<main class="small-4 medium-3 col auto">
    <form action="symbols" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label>
            <input type="file" name="symbols[]" accept="*.png" multiple>
        </label>
        <input type="submit" value="Upload">
    </form>
    <ul class="symbols">
        <?php $__currentLoopData = $symbols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symbol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <img src="<?php echo e($symbol->path); ?>"/>
            <div class="buttons">
                <?php if($symbol->disabled): ?>
                <a href="symbols/<?php echo e($symbol->id); ?>/update">Enable</a>
                <a href="symbols/<?php echo e($symbol->id); ?>/delete" class="delete">Delete</a>
                <?php else: ?>
                <a href="symbols/<?php echo e($symbol->id); ?>/update">Disable</a>
                <?php endif; ?>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
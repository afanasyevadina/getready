<?php $__env->startSection('content'); ?>
<main class="small-4 medium-3 col auto">
    <form action="symbols" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <!-- file input -->
        <label class="file-input">
            <div><!-- here will be pa preview --></div>
            <img class="bg" src="<?php echo e(asset('public/img/select.png')); ?>" alt="Select files">
            <input type="file" id="file" name="symbols[]" accept="*.png" multiple required>
        </label>
        <input type="submit" value="Upload">
    </form>
    <ul class="symbols">
        <?php $__currentLoopData = $symbols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symbol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- list of symbols -->
        <li>
            <img src="<?php echo e($symbol->path); ?>" class="<?php echo e($symbol->disabled ? 'disabled' : ''); ?>"/>
            <div class="buttons">
                <!-- show buttons according to state -->
                <?php if($symbol->disabled): ?>
                <a href="symbols/<?php echo e($symbol->id); ?>/update">Enable</a>
                <a href="symbols/<?php echo e($symbol->id); ?>/delete" class="delete">Delete</a>
                <?php else: ?>
                <a href="symbols/<?php echo e($symbol->id); ?>/update">Disable</a>
                <?php endif; ?>
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</main>
<script type="text/javascript">
    //upload files by drag and drop
    document.getElementById('file').addEventListener('change', function(){
        for(var i = 0; i < this.files.length; i++) {
            if(this.files[i].type.indexOf('image') != -1) {
                var reader = new FileReader();
                reader.onload = (function(theFile) {
                    return function(e) {
                            // Render thumbnail.
                            var span = document.createElement('span');
                            span.innerHTML = ['<img class="thumbnail" title="', theFile.name, '" src="', e.target.result, '" />'].join('');
                            document.querySelector('.file-input > div').insertBefore(span, null);
                            document.querySelector('.file-input').classList.add('filled');
                        };
                    })(this.files[i]);
                    reader.readAsDataURL(this.files[i]);
                }
            }
        });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
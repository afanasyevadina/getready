<?php $__env->startSection('content'); ?>
<main class="small-4 col">
        <h1>Order Detail for #ORDER <?php echo e($order->id); ?></h1>
    
        <ol class="status-bar">
            <!-- highlight current status -->
          <li class="<?php echo e($order->status == 'Open' ? 'active': ''); ?>">Opened</li>
          <li class="<?php echo e($order->status == 'Prepared' ? 'active': ''); ?>">Prepared</li>
          <li class="<?php echo e($order->status == 'Closed/Delivered' ? 'active': ''); ?>">Closed/Delivered</li>
        </ol>
    
        <div class="contacts">
            <!-- order info -->
            <p>First Name: <?php echo e($order->firstname); ?></p>
            <p>Last Name: <?php echo e($order->lastname); ?></p>
            <p>E-mail: <?php echo e($order->email); ?></p>
            <p><i>Remarks: <?php echo e($order->remarks); ?></i></p>
        </div>
        <ul class="product-list">
            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <!-- preview -->
                <div class="img">
                    <img class="placeholder" src="<?php echo e($item->product->path[$item->color->name]); ?>" alt="">
                    <img src="<?php echo e($item->symbol !== null ? $item->symbol->path : ''); ?>" class="thumb"/>
                </div>
                <div class="info">
                    <p>Product ID: <?php echo e($item->product_id); ?> (<?php echo e($item->product->name); ?>)</p>
                    <p>Price: $<?php echo e($item->product->price); ?></p>
                    <p>Color ID: <?php echo e($item->color_id); ?> (<?php echo e($item->color->name); ?>)</p>
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <form action="<?php echo e(action('OrderController@update', ['id' => $order->id])); ?>" method="POST" class="update-order">
            <?php echo csrf_field(); ?>
            <label>
            Remarks<br>
            <textarea name="remarks"></textarea>
            </label>
            <!-- show available status -->
            <?php if($order->status != 'Closed/Delivered'): ?>        
            <p>
                Status<br>
                <?php if($order->status == 'Open'): ?>
                <label>
                    <input type="radio" name="status" value="Open" checked>Opened
                </label>
                <label>
                    <input type="radio" name="status" value="Prepared">Prepared
                </label>
                <?php endif; ?>
                <?php if($order->status == 'Prepared'): ?>
                <label>
                    <input type="radio" name="status" value="Prepared" checked>Prepared
                </label>
                <label>
                    <input type="radio" name="status" value="Closed/Delivered">Closed/Delivered
                </label>
                <?php endif; ?>
            </p>
            <?php endif; ?>
        
            <p><input type="submit" value="Update"></p>
        </form>
    
      </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
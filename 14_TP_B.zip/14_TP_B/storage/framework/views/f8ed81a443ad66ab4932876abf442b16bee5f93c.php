<?php $__env->startSection('content'); ?>
<main class="small-4 medium-3 col">
    <h1>Pre-Orders</h1>
    <?php echo e($orders->render()); ?>

    <ol class="order-list">
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="orders/<?php echo e($order->id); ?>">
                <li>
                    <span class="status">
                        Status: <?php echo e($order->status); ?><br>
                        Order date: <?php echo e(date('d.m.Y', strtotime($order->created_at))); ?>

                    </span>
                    <strong>#ORDER<?php echo e($order->id); ?></strong>
                    <ul class="product-list">
                        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <div class="img">
                                    <img class="placeholder" src="<?php echo e($item->product->path[$item->color->name]); ?>" alt="">
                                    <img src="<?php echo e($item->symbol->path); ?>" class="thumb"/>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</main>
<aside class="small-4 medium-1 col">
    <h2>Filters</h2>
    <form action="orders">
        <label>Date from</label>
        <input type="date" name="from" value="<?php echo e(@$_GET['from'] ?? date('Y-m-d')); ?>" />
        <label>Date to</label>
        <input type="date" name="to" value="<?php echo e(@$_GET['to'] ?? date('Y-m-d')); ?>" />
        <label>Status filter</label>
        <select name="status">
            <option value="">All orders</option>
            <option <?php echo e(@$_GET['status'] == 'Open' ? 'selected' : ''); ?>>Open</option>
            <option <?php echo e(@$_GET['status'] == 'Prepared' ? 'selected' : ''); ?>>Prepared</option>
            <option <?php echo e(@$_GET['status'] == 'Closed/Delivered' ? 'selected' : ''); ?>>Closed/Delivered</option>
        </select>
        <input type="submit" value="Show" class="filter"/>
    </form>
</aside>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
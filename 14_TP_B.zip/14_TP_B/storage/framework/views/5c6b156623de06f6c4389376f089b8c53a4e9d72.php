<?php $__env->startSection('content'); ?>

<div id="app">
	<img v-for="symbol in symbols" :src="symbol" alt="Symbol" />
</div>

<script type="text/javascript">
	var app = new Vue({
		el: '#app',
		data: {
			symbols: []
		},
		created() {
			axios.get('api/symbols')
			.then(response => this.symbols = response.data)
		}
	})
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>